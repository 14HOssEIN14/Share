import requests
from bs4 import BeautifulSoup

def download_html(url, output_html="page.html"):
    headers = {"User-Agent": "Mozilla/5.0"}  # جلوگیری از بلاک شدن
    response = requests.get(url, headers=headers, verify=False)
    
    if response.status_code == 200:
        with open(output_html, "w", encoding="utf-8") as file:
            file.write(response.text)
        print(f"HTML page saved as {output_html}")
    else:
        print("Failed to retrieve page. Status code:", response.status_code)

def extract_divar_links_from_file(input_html="page.html", output_file="divar_links.txt"):
    with open(input_html, "r", encoding="utf-8") as file:
        soup = BeautifulSoup(file, "html.parser")
    
    links = [f"https://divar.ir{link['href']}" for link in soup.find_all("a", class_="kt-post-card__action")]
    
    with open(output_file, "w", encoding="utf-8") as file:
        for link in links:
            file.write(link + "\n")
    
    print(f"{len(links)} links extracted and saved to {output_file}")

# دانلود صفحه و استخراج لینک‌ها
download_html("https://divar.ir/s/tehran/buy-apartment/jeyhoon?tab=default&business-type=personal&building-age=-20&price=1800000000-5000000000&districts=284%2C1002")
extract_divar_links_from_file()
