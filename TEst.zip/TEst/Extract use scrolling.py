

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
import time

def load_all_ads(url, wait_time=2, max_scrolls=50):
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # اجرای بدون نمایش مرورگر
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--window-size=1920x1080")
    chrome_options.add_argument("--log-level=3")  # حذف لاگ‌های اضافی

    service = Service("C:\chromedriver\chromedriver.exe")  
    driver = webdriver.Chrome(service=service, options=chrome_options)

    driver.get(url)
    time.sleep(wait_time)  # زمان اولیه برای لود شدن صفحه

    all_ads = set()  # مجموعه‌ای برای ذخیره‌ی آگهی‌های مشاهده‌شده
    last_height = driver.execute_script("return document.body.scrollHeight")

    for _ in range(max_scrolls):
        page_source = driver.page_source
        soup = BeautifulSoup(page_source, "html.parser")
        
        # استخراج لینک‌های جدید از صفحه
        current_ads = set(f"https://divar.ir{link['href']}" for link in soup.find_all("a", class_="kt-post-card__action"))
        
        # بررسی آگهی‌های جدید
        new_ads = current_ads - all_ads
        if not new_ads:
            print("هیچ آگهی جدیدی اضافه نشد، اسکرول متوقف شد.")
            break  # اگر آگهی جدیدی پیدا نشد، یعنی انتهای صفحه است

        all_ads.update(new_ads)
        print(f"تعداد آگهی‌های جدید: {len(new_ads)}, مجموع: {len(all_ads)}")

        # اسکرول به پایین برای بارگذاری آگهی‌های جدید
        driver.find_element(By.TAG_NAME, "body").send_keys(Keys.END)
        time.sleep(wait_time)  # صبر برای بارگذاری آگهی‌ها

        # بررسی اینکه آیا صفحه باز هم قابل اسکرول هست یا نه
        new_height = driver.execute_script("return document.body.scrollHeight")
        if new_height == last_height:
            print("به انتهای صفحه رسیدیم.")
            break
        last_height = new_height

    driver.quit()
    return all_ads

def save_ads_to_file(ads, output_file="divar_links.txt"):
    with open(output_file, "w", encoding="utf-8") as file:
        for ad in ads:
            file.write(ad + "\n")
    print(f"{len(ads)} لینک استخراج شد و در {output_file} ذخیره شد.")

# اجرای برنامه
url = "https://divar.ir/s/tehran/buy-apartment/jeyhoon?tab=default&business-type=personal&building-age=-20&price=1800000000-5000000000&districts=284%2C1002"
ads = load_all_ads(url)
save_ads_to_file(ads)