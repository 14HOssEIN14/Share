



import requests
import asyncio
from telegram import Bot
from telegram.request import HTTPXRequest

# تنظیمات تلگرام
TOKEN = "7778567132:AAGtgsEum18n7N4qL2a4bpVsevM3pdxBw-0"
CHAT_ID = "-1002545092600"  # مقدار CHAT_ID گروه
TELEGRAM_PROXY = "socks5://192.168.34.125:1080"  # پراکسی تلگرام

# 🔹 API CoinMarketCap
CMC_API_KEY = "4605552a-3b09-4ba7-82f5-ad4d46dd9264"
CMC_URL = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest"

# 🔹 لیست ارزهای دیجیتال معروف برای نمایش
CURRENCIES = ["BTC", "ETH", "BNB", "XRP", "DOGE", "ADA", "SOL", "DOT", "LTC", "SHIB"]

async def send_telegram_message(message):
    """ ارسال پیام به تلگرام با پراکسی """
    request = HTTPXRequest(proxy=TELEGRAM_PROXY)
    bot = Bot(token=TOKEN, request=request)
    await bot.send_message(chat_id=CHAT_ID, text=message, parse_mode="Markdown", disable_web_page_preview=True)

def get_crypto_prices():
    """ دریافت قیمت ارزهای دیجیتال از CoinMarketCap """
    headers = {
        "X-CMC_PRO_API_KEY": CMC_API_KEY,
        "Accepts": "application/json"
    }
    params = {"symbol": ",".join(CURRENCIES), "convert": "USD"}
    
    try:
        response = requests.get(CMC_URL, headers=headers, params=params, timeout=10)
        if response.status_code == 200:
            return response.json()["data"]
        return None
    except requests.exceptions.RequestException:
        return None

async def fetch_prices():
    """ دریافت قیمت‌ها و ارسال به تلگرام """
    data = get_crypto_prices()

    if data:
        message = "🚀 **جدیدترین قیمت ارزهای دیجیتال | CoinMarketCap** 📊\n\n"
        
        for currency in CURRENCIES:
            price = data[currency]["quote"]["USD"]["price"]
            price_formatted = f"{price:,.2f}"
            change_24h = data[currency]["quote"]["USD"]["percent_change_24h"]
            emoji = "🟢" if change_24h > 0 else "🔴"

            message += f"🔹 **{currency}**: `{price_formatted} دلار` {emoji}\n"

        message += "\n📅 **بروزرسانی: همین لحظه** 🔄"
        await send_telegram_message(message)
    else:
        await send_telegram_message("❌ خطا در دریافت قیمت ارزهای دیجیتال، لطفاً بعداً امتحان کنید.")

async def main():
    while True:
        await fetch_prices()  # هر ۵ دقیقه بروزرسانی قیمت
        await asyncio.sleep(300)

if __name__ == "__main__":
    asyncio.run(main())