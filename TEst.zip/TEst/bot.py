from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.action_chains import ActionChains
from webdriver_manager.chrome import ChromeDriverManager
import time

# Config
DIVAR_URL = "https://divar.ir/s/tehran/buy-apartment/jeyhoon?tab=default&business-type=personal&building-age=-20&price=1800000000-5000000000&districts=284%2C1002"
SCROLL_PAUSE_TIME = 3  # Pause time after each scroll
MAX_SCROLLS = 30  # Maximum number of scrolls to load more ads

# Setup Selenium WebDriver
options = webdriver.ChromeOptions()
options.add_argument("--headless")  # Run in headless mode
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

def get_all_ads():
    driver.get(DIVAR_URL)
    time.sleep(SCROLL_PAUSE_TIME)  # Wait for initial page load
    
    last_height = driver.execute_script("return document.body.scrollHeight")
    
    for _ in range(MAX_SCROLLS):
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(SCROLL_PAUSE_TIME)
        new_height = driver.execute_script("return document.body.scrollHeight")

        if new_height == last_height:
            print("No more new ads loaded.")
            break  # Stop scrolling if no new ads are loaded
        last_height = new_height

    # Finding all ads
    ads = driver.find_elements(By.CLASS_NAME, "kt-post-card__action")
    ad_links = []
    
    for ad in ads:
        link = ad.get_attribute("href")
        if link and link.startswith("/v/"):
            full_link = link
            ad_links.append(full_link)
    
    return ad_links

# Run and print results
ads = get_all_ads()
driver.quit()

if ads:
    print(f"✅ Total ads found: {len(ads)}")
    for ad in ads:
        print(ad)
else:
    print("❌ No ads found.")