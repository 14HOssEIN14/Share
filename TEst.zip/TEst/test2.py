import requests
import asyncio
import os
from bs4 import BeautifulSoup
from telegram import Bot
from telegram.request import HTTPXRequest

# تنظیمات
TOKEN = "7778567132:AAGtgsEum18n7N4qL2a4bpVsevM3pdxBw-0"
CHAT_ID = "-1002545092600"
URL = "https://divar.ir/s/tehran/buy-apartment/jeyhoon?tab=default&business-type=personal&building-age=-20&price=1800000000-5000000000&districts=284%2C1002"
FILENAME = "divar_links.txt"

# 📌 تنظیم پراکسی فقط برای تلگرام
TELEGRAM_PROXY = "socks5://192.168.34.125:1080"  # پراکسی تلگرام

async def send_telegram_message(message):
    request = HTTPXRequest(proxy=TELEGRAM_PROXY)  # تنظیم پراکسی برای تلگرام
    bot = Bot(token=TOKEN, request=request)
    await bot.send_message(chat_id=CHAT_ID, text=message)

def download_html(url):
    """دریافت صفحه دیوار بدون پراکسی"""
    headers = {"User-Agent": "Mozilla/5.0"}
    try:
        response = requests.get(url, headers=headers, verify=False, timeout=10)
        if response.status_code == 200:
            return response.text
        else:
            print("خطا در دریافت صفحه:", response.status_code)
            return None
    except requests.exceptions.RequestException as e:
        print("خطا در درخواست دیوار:", e)
        return None

def extract_divar_links(html):
    soup = BeautifulSoup(html, "html.parser")
    return {f"https://divar.ir{link['href']}" for link in soup.find_all("a", class_="kt-post-card__action")}

def load_previous_links():
    if os.path.exists(FILENAME):
        with open(FILENAME, "r", encoding="utf-8") as file:
            return set(file.read().splitlines())
    return set()

def save_links(links):
    with open(FILENAME, "w", encoding="utf-8") as file:
        file.write("\n".join(links))

async def initial_run():
    """ اجرای اولیه - دریافت همه آگهی‌ها و ارسال یکجا به تلگرام """
    html = download_html(URL)
    if html:
        links = extract_divar_links(html)
        save_links(links)  # ذخیره لینک‌ها

        if links:
            formatted_links = "\n\n".join([f"📌 {i+1}. [مشاهده آگهی]({link})" for i, link in enumerate(links)])
            message = f"✅ **لیست اولیه آگهی‌ها:**\n\n{formatted_links}"
            await send_telegram_message(message)
        else:
            await send_telegram_message("⚠️ هیچ آگهی‌ای پیدا نشد.")

async def check_for_updates():
    """ بررسی تغییرات در آگهی‌ها هر ۳ دقیقه """
    html = download_html(URL)
    if html:
        new_links = extract_divar_links(html)
        old_links = load_previous_links()

        added_links = new_links - old_links  # آگهی‌های جدید
        removed_links = old_links - new_links  # آگهی‌های حذف‌شده

        if added_links:
            formatted_links = "\n\n".join([f"📌 {i+1}. [مشاهده آگهی]({link})" for i, link in enumerate(added_links)])
            message = f"🔥 **آگهی‌های جدید:**\n\n{formatted_links}"
            await send_telegram_message(message)
        else:
            await send_telegram_message("✅ هیچ آگهی جدیدی اضافه نشده.")

        save_links(new_links)  # ذخیره لیست جدید

async def main():
    await initial_run()  # اجرای اولیه
    while True:
        await asyncio.sleep(180)  # هر ۳ دقیقه
        await check_for_updates()

if __name__ == "__main__":
    asyncio.run(main())